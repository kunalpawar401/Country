package edu.uga.cs.countryquiz;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static android.content.ContentValues.TAG;

/**
 * A simple {@link Fragment} that displays the list of countries.
 * This class also contains an onclick listener allowing the user
 * to interact with the list.
 * Use the {@link QuizStartFragment} factory method to
 * create an instance of this fragment.
 */
public class QuizStartFragment extends Fragment {

    public static final String EXTRA_SCORE = "extra score";

    private TextView textViewQuestion;
    private TextView textViewScore;
    private TextView textViewQuestionCount;
    private TextView textViewCountDown;
    private RadioGroup rbGroup;
    private RadioButton radiobutton1;
    private RadioButton radiobutton2;
    private RadioButton radiobutton3;
    private Button buttonComfirmNext;

    private int questionCounter;
    private int questionCountTotal;
    private Question currentQuestion;

    private int score;
    private boolean answered;



    private List<Question> questionList;

    //initilizing variable for selected item on the list
    public String selectedItem;

    public QuizStartFragment() {
        // Required empty public constructor
    }

    /**
     * Initializing program's ativity.
     *
     * @param savedInstanceState Bundle
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    /**
     * Inflating the XML layout for the Fragment in this callback.
     *
     * @param inflater           LayoutInflater
     * @param container          ViewGroup
     * @param savedInstanceState Bundle
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_quiz_start, container, false);

        textViewQuestion = view.findViewById(R.id.text_view_question);
        textViewScore = view.findViewById(R.id.text_view_score);
        textViewQuestionCount = view.findViewById(R.id.text_view_question_count);
        rbGroup = view.findViewById(R.id.radio_group);
        radiobutton1 = view.findViewById(R.id.radio_button1);
        radiobutton2 = view.findViewById(R.id.radio_button2);
        radiobutton3 = view.findViewById(R.id.radio_button3);
        buttonComfirmNext = view.findViewById(R.id.button_comfirm_next);

        QuizDbHelper dbHelper = new QuizDbHelper(getContext());
        questionList = dbHelper.getAllQuestions();
        questionCountTotal = questionList.size();
        Collections.shuffle(questionList);
        RadioButton radioButtonSelected = view.findViewById(rbGroup.getCheckedRadioButtonId());


        showNextQuestion();

        buttonComfirmNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!answered){
                    if (radiobutton1.isChecked() || radiobutton2.isChecked() || radiobutton3.isChecked()) {
                        checkAnswer();
                    }
                    else {
                        Toast.makeText(getActivity(),"Please select an answer.", Toast.LENGTH_LONG).show();
                    }
                } else {
                    showNextQuestion();
                }
            }
        });
        //initializing array for the list list of countries



        //return the view
        return view;
    }

    private void showNextQuestion() {
        rbGroup.clearCheck();

        if (questionCounter < questionCountTotal) {
            currentQuestion = questionList.get(questionCounter);
            textViewQuestion.setText(currentQuestion.getQuestion());
            radiobutton1.setText(currentQuestion.getOption1());
            radiobutton2.setText(currentQuestion.getOption2());
            radiobutton3.setText(currentQuestion.getOption3());

            questionCounter++;
            textViewQuestionCount.setText("Question: " + questionCounter + "/" + questionCountTotal);
            answered = false;
            buttonComfirmNext.setText("Submit");
        }
        else {
            finishQuiz();
        }
    }

    private void checkAnswer() {
        answered = true;

        RadioButton radioButtonSelected = getActivity().findViewById(rbGroup.getCheckedRadioButtonId());
        int answerNr = rbGroup.indexOfChild(radioButtonSelected);

        if (answerNr == currentQuestion.getAnswerNr()) {
            score++;
            textViewScore.setText("Score: " + score);
        }
        questionfinished();
    }

    public void questionfinished() {
        if (questionCounter < questionCountTotal) {
            buttonComfirmNext.setText("Next");
        }
        else{
            buttonComfirmNext.setText("Finish");
        }
    }

    private void finishQuiz() {
        Bundle bundle = new Bundle();
        bundle.putInt("score", score);
        ResultFragment resultFragment  = new ResultFragment();
        resultFragment.setArguments(bundle);
        FragmentManager fragmentManager = getParentFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerView1, resultFragment)
                .setReorderingAllowed(true)
                .addToBackStack("yes")
                .commit();

    }

}
